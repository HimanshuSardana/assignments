import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

RANDOM_STATE = 69

DATA_URL_WISDM = (
    "https://www.cis.fordham.edu/wisdm/dataset/wisdm-dataset-v1.1/WISDM_ar_v1.1_raw.txt"
)

try:
    # The file is space-separated, but columns are user_id;activity;timestamp,X,Y,Z;
    df = pd.read_csv(DATA_URL_WISDM, header=None, comment=";")
except Exception:
    print("Could not load WISDM data from URL. Please ensure access to the raw file.")
    exit()  # Exit if data can't be loaded

# The raw data is messy; we need to split the first column by comma/semicolon
# The columns are typically: user, activity, timestamp, X, Y, Z,
# where Z often has a trailing semicolon that pandas reads into the last column.
df_split = df[0].str.split(",", expand=True)

# Assign temporary columns for processing
df_split.columns = ["user_activity_timestamp", "X", "Y", "Z_semicolon"]

# Further split the first column
df_temp = df_split["user_activity_timestamp"].str.split(";", expand=True)
df_temp.columns = ["user_id", "Activity", "Timestamp"]

# Combine the data
df_final = pd.concat([df_temp, df_split[["X", "Y"]], df_split["Z_semicolon"]], axis=1)
df_final.columns = ["user_id", "Activity", "Timestamp", "accel_x", "accel_y", "accel_z"]

# Clean and convert numeric columns
# accel_z has a trailing semicolon, remove it and convert to numeric
df_final["accel_z"] = df_final["accel_z"].str.replace(";", "", regex=False)
df_final = df_final.apply(pd.to_numeric, errors="coerce")

# Drop missing/dirty entries (NaNs generated from failed numeric conversion)
df_final = df_final.dropna()

# Create binary activity label
# 1 = vigorous motion (Jogging, Upstairs)
# 0 = light/static motion (Walking, Sitting, Standing, Downstairs)
VIGOROUS_ACTIVITIES = ["Jogging", "Upstairs"]

df_final["target"] = df_final["Activity"].apply(
    lambda x: 1 if x in VIGOROUS_ACTIVITIES else 0
)

# Select only accelerometer features
X = df_final[["accel_x", "accel_y", "accel_z"]]
y = df_final["target"]

# Train-test split (70/30)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=RANDOM_STATE, stratify=y
)

# Scaling features (important for AdaBoost stability, though less critical for trees)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print(f"Processed Data Shapes: Train {X_train.shape}, Test {X_test.shape}")
print("-" * 50)


# =========================================================================
# Part B — Weak Classifier Baseline
# =========================================================================
print("PART B: WEAK CLASSIFIER BASELINE (DECISION STUMP)")

stump_wisdm = DecisionTreeClassifier(max_depth=1, random_state=RANDOM_STATE)
stump_wisdm.fit(X_train_scaled, y_train)

# Predictions
y_train_pred = stump_wisdm.predict(X_train_scaled)
y_test_pred = stump_wisdm.predict(X_test_scaled)

# Report
train_acc = accuracy_score(y_train, y_train_pred)
test_acc = accuracy_score(y_test, y_test_pred)
cm = confusion_matrix(y_test, y_test_pred)

print(f"Training Accuracy: {train_acc:.4f}")
print(f"Test Accuracy:     {test_acc:.4f}")
print("\nConfusion Matrix (Test Set):\n", cm)

print("\n--- Interpretation of Stump Result ---")
print(
    "The Decision Stump likely performs reasonably well because the task is inherently linear (vigorous motion generates significantly higher raw acceleration readings than light/static motion). The stump finds a simple threshold, e.g., 'If accel_X > X, predict 1', which captures the high-level difference between the two activity groups."
)
print("-" * 50)


# =========================================================================
# Part C — Manual AdaBoost (T = 20 rounds)
# =========================================================================
print("PART C: MANUAL ADABOOST IMPLEMENTATION (T=20 ROUNDS)")

# Prepare labels for AdaBoost formula: 0/1 -> -1/1
y_train_signed = np.where(y_train == 0, -1, 1)
y_test_signed = np.where(y_test == 0, -1, 1)

N = X_train_scaled.shape[0]
T = 20  # Number of iterations
D = np.full(N, 1 / N)  # Initial uniform weights D_i

error_history = []
alpha_history = []
model_history = []

for t in range(T):
    print(f"\n--- ITERATION {t + 1} ---")

    # 1. Train Decision Stump h_t using sample weights D
    h_t = DecisionTreeClassifier(max_depth=1, random_state=t)
    h_t.fit(X_train_scaled, y_train, sample_weight=D)

    y_pred_01 = h_t.predict(X_train_scaled)
    y_pred_signed = np.where(y_pred_01 == 0, -1, 1)

    # 2. Calculate the weighted error (misclassified samples)
    misclassified_indices = np.where(y_pred_signed != y_train_signed)[0]
    epsilon_t = np.sum(D[misclassified_indices])

    if epsilon_t == 0 or epsilon_t >= 0.5:
        print(f"Weighted error is {epsilon_t:.4f}. Stopping AdaBoost early.")
        break

    # 3. Calculate alpha (confidence)
    alpha_t = 0.5 * np.log((1 - epsilon_t) / epsilon_t)

    # 4. Print required outputs
    print(f"Weighted Error (ε): {epsilon_t:.4f}")
    print(f"Alpha (α): {alpha_t:.4f}")

    # Only print first 5 misclassified indices and their weights
    print(
        f"Misclassified samples ({len(misclassified_indices)} total): {misclassified_indices[:5]}..."
    )
    print(
        f"Initial weights of these samples: {D[misclassified_indices[:5]].round(6)}..."
    )

    # 5. Update and Normalize weights D
    D *= np.exp(-alpha_t * y_train_signed * y_pred_signed)
    D /= np.sum(D)

    # Store history and model
    error_history.append(epsilon_t)
    alpha_history.append(alpha_t)
    model_history.append((alpha_t, h_t))


# Final Manual AdaBoost Prediction Function (re-used from Q1)
def manual_ada_predict(X, model_history):
    N_samples = X.shape[0]
    final_pred_signed = np.zeros(N_samples)

    for alpha, h_t in model_history:
        y_pred_01 = h_t.predict(X)
        y_pred_signed = np.where(y_pred_01 == 0, -1, 1)
        final_pred_signed += alpha * y_pred_signed

    final_pred_01 = np.where(final_pred_signed > 0, 1, 0)
    return final_pred_01


# Report Manual AdaBoost Performance
y_manual_pred_train = manual_ada_predict(X_train_scaled, model_history)
y_manual_pred_test = manual_ada_predict(X_test_scaled, model_history)

manual_train_acc = accuracy_score(y_train, y_manual_pred_train)
manual_test_acc = accuracy_score(y_test, y_manual_pred_test)
manual_cm = confusion_matrix(y_test, y_manual_pred_test)

print("\n" + "=" * 50)
print("MANUAL ADABOOST FINAL REPORT (T=20)")
print(f"Train Accuracy: {manual_train_acc:.4f}")
print(f"Test Accuracy:  {manual_test_acc:.4f}")
print("\nConfusion Matrix (Test Set):\n", manual_cm)

# --- Manual AdaBoost Plots ---
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
iterations = np.arange(1, len(error_history) + 1)

# Plot 1: Boosting Round vs Error
ax1.plot(iterations, error_history, marker="o", linestyle="-", color="red")
ax1.set_title("Manual AdaBoost: Boosting Round vs Weighted Error (ε)")
ax1.set_xlabel("Boosting Round")
ax1.set_ylabel("Weighted Error (ε)")
ax1.grid(True)

# Plot 2: Boosting Round vs Alpha
ax2.plot(iterations, alpha_history, marker="o", linestyle="-", color="blue")
ax2.set_title("Manual AdaBoost: Boosting Round vs Alpha (α)")
ax2.set_xlabel("Boosting Round")
ax2.set_ylabel("Alpha (α) / Classifier Confidence")
ax2.grid(True)

plt.tight_layout()
plt.show()

print("\n--- Interpretation: How Weights Shifted Over Time ---")
print(
    "The weights shift dramatically over the 20 rounds. Initially uniform, after the first round, the weights of the misclassified static/light activity samples (0) and vigorous motion samples (1) increase."
)
print(
    "Each subsequent stump is then forced to prioritize the 'hardest' samples—those points where the previous 19 stumps disagreed or failed. This **weight reallocation** is the core reason AdaBoost can transform a very weak classifier into a strong one."
)
print("-" * 50)


# =========================================================================
# Part D — Sklearn AdaBoost
# =========================================================================
print("PART D: SKLEARN ADABOOST CLASSIFIER")

sklearn_ada_clf = AdaBoostClassifier(
    estimator=DecisionTreeClassifier(max_depth=1, random_state=RANDOM_STATE),
    n_estimators=100,
    learning_rate=1.0,
    random_state=RANDOM_STATE,
    algorithm="SAMME",
)

sklearn_ada_clf.fit(X_train_scaled, y_train)

# Predictions
y_sklearn_train_pred = sklearn_ada_clf.predict(X_train_scaled)
y_sklearn_test_pred = sklearn_ada_clf.predict(X_test_scaled)

sklearn_train_acc = accuracy_score(y_train, y_sklearn_train_pred)
sklearn_test_acc = accuracy_score(y_test, y_sklearn_test_pred)
sklearn_cm = confusion_matrix(y_test, y_sklearn_test_pred)

print(f"Sklearn Train Accuracy: {sklearn_train_acc:.4f}")
print(f"Sklearn Test Accuracy:  {sklearn_test_acc:.4f}")
print("\nConfusion Matrix (Test Set):\n", sklearn_cm)

print("\n--- Comparison with Manual Implementation ---")
print(f"Manual Test Accuracy (T=20): {manual_test_acc:.4f}")
print(f"Sklearn Test Accuracy (T=100): {sklearn_test_acc:.4f}")

if sklearn_test_acc > manual_test_acc:
    print(
        "\nSklearn's AdaBoost performs significantly better due to using **100 estimators** (5 times more than the manual implementation) and having a slight implementation advantage in stability and optimization."
    )
else:
    print(
        "\nSklearn's AdaBoost performance is comparable, which is impressive given the simplicity of the manual approach. The core algorithm principles are validated."
    )
print("-" * 50)
